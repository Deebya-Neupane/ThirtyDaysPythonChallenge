# Example file for working with importing and using modules.

# Import the math module, which contains features for workinig with math.
import math 

# The math module contains lots of pre-built functions.
print("The square root of 25 is", math.sqrt(25))

# In addition to functions, some modules contain useful constants.
print("pi is:", math.pi)

# Try someof the math functions for yourself here:
print("tau is:" , math.tau)
print("The tan value is:", math.tan(90))
print (math.tan(-90))
print (math.e)     #(The math.e constant returns the Eular's number)
